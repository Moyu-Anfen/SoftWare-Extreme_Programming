

### 1.安装依赖

```javascript
	npm install or npm i
```

### 2.启动运行
```javascript
	npm run start
```