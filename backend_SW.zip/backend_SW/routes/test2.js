const fs = require('fs')
const crypto = require('crypto')

const publicKey = fs.readFileSync('../bin/rsa_public_key.pem').toString('utf-8')
const privateKey = fs.readFileSync('../bin/rsa_private_key.pem').toString('utf-8')

// console.log(publicKey) //公钥
// console.log(privateKey) //私钥

const data = 'ceshi'
var buffer = new Buffer(data)
var encrypted = crypto.publicEncrypt(publicKey, buffer)

// 得到加密的密文
let encryptedStr = encrypted.toString('base64')
// console.log(encryptedStr)
//rkOkBtFX+xVcAMZ+wI7A0qY/HvDy8dRWvcw/+s7AYqsaGULlr12/RhrcRl7npIIb6t+L53/KkTGX56h8NwNsUsDHBVeL5kgOTWm6f5yOzaoz3ppnVGJbsLAO69I9qV26CzrwS8/PMtDMLbrJgpB/la4Nl7WDJX/GgOcmOFbNmTo=


// 解密
var buffer2 = new Buffer(encryptedStr, 'base64')
var decrypted = crypto.privateDecrypt(
    {
        key: privateKey,
        padding: crypto.constants.RSA_PKCS1_OAEP_PADDING
    },
    buffer2
)

console.log("解密后：",decrypted.toString("utf8"))  //ceshi