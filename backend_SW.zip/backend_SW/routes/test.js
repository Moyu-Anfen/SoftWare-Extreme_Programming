const crypto = require('crypto');
// 生成RSA密钥对的函数
// function generateKeyPair() {
//   // 使用RSA和指定的位数
//   const keyPair = crypto.generateKeyPairSync('rsa', {
//     modulusLength: 2048, // 标准的2048位长度
//   });
//   return {
//     publicKey: keyPair.publicKey.export({ type: 'pkcs1', format: 'pem' }),
//     privateKey: keyPair.privateKey.export({ type: 'pkcs1', format: 'pem' }),
//   };
// }
// // 使用函数并保存密钥
// const { publicKey, privateKey } = generateKeyPair();
// console.log('公钥:', publicKey);
// console.log('私钥:', privateKey);

const publicKey = `
-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCaOk72MMJSyVrZNJALpOb5i7O7
bzRh9IxNTzP6Zs7rE5baH5dVmyMx2RJIkTQl6dQfzHKzpwydqO/kNMWSLjx1EzYO
dFPBX/KtEIu0uX/ywTDqO/fCW0fYag07SQlnfp0jCehksXjnAIsPqWSRKzwpRpHe
vkPNwudQUTFX3WF58QIDAQAB
-----END PUBLIC KEY-----
`

const privateKey = `
-----BEGIN RSA PRIVATE KEY-----
MIICXQIBAAKBgQCaOk72MMJSyVrZNJALpOb5i7O7bzRh9IxNTzP6Zs7rE5baH5dV
myMx2RJIkTQl6dQfzHKzpwydqO/kNMWSLjx1EzYOdFPBX/KtEIu0uX/ywTDqO/fC
W0fYag07SQlnfp0jCehksXjnAIsPqWSRKzwpRpHevkPNwudQUTFX3WF58QIDAQAB
AoGAEv+FxIvjFCGboE/6QoTwsuLDpB4hvMNMGSXdiEXrzUdfeMUVdkUjA7vypZ/F
Zbo1GCmuI3U7d5xc2Karg8NQTQa5eMWpDXSD53YWDH+Y8KSfI6KigcymujxLiZ2o
YhJPogSsMO0TY4DfpW0o+wImnZSFpW4lutEjs4YYW+KJDQUCQQDHtPX3YbrwSerJ
/w3EhtZ9/FvXdaOEimzoMufRQs43cwuMv/UltZs4SMqdMVTRYJbFrpbBfidKMXuq
3vG6/3A/AkEAxbOIEtjf/CA+zbc4lVoCr5ljThWXxzd6UL2A/4dwkjueBwd4KawA
hkvF/UBj6/XmkGMbudNp8Ke66DhlmTyJzwJBALJ1XydFSgvXwdvn86Ge7KWAkYGk
Og8Cs/d7JfS1whmC0Nth3etoseBGC+kUYDsKGTFlpooZ9XozZdN3joQQJ3kCQHu7
vklVdPH+WHA14PMQj6fJT26acxDa9vG7eRX0dY8AQwpRMXKbVQS4PeUfvKn8j94E
OWEXITHeOEuIqIW8bt8CQQCEXr5u9QQHrvMvPkW+VdsiEtC35iXJfkRVdBf9bnE8
QS64JKpZi9YFJ3qGFV4x/JM6hG+B314hP4BZkjSAUIB/
-----END RSA PRIVATE KEY-----
`
// 公钥加密函数
function encryptWithPublicKey(publicKey, message) {
  const bufferMessage = Buffer.from(message, 'utf8');
  console.log('@@@@:', bufferMessage);
  return crypto.publicEncrypt(publicKey, bufferMessage);
}
// 需要加密的数据
const message = '12345';
// 使用公钥进行加密
const encryptedMessage = encryptWithPublicKey(publicKey, message);
console.log('加密后的数据:', encryptedMessage.toString('base64'));
console.log('@@@', encryptedMessage);
// 私钥解密函数
function decryptWithPrivateKey(privateKey, encryptedMessage) {
  const bufferEncryptedMessage = Buffer.from(encryptedMessage, 'base64');
  console.log(bufferEncryptedMessage)
  return crypto.privateDecrypt(privateKey, bufferEncryptedMessage);
}
// 使用私钥解密
const decryptedMessage = decryptWithPrivateKey(privateKey, encryptedMessage);
console.log('@@@@:', decryptedMessage);
console.log('解密后的消息:', decryptedMessage.toString('utf8'));